package sample;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.TimeSeries;

import sample.logic.GridDBLogic;
import sample.logic.InstrumentLogLogic;
import sample.row.InstrumentLog;

/**
 * Sample of Index creation and deletion
 */
public class TimeSeriesDrop {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			// Drop TimeSeries Container
			for (int i = 0; i < GridDBLogic.JP_PREFECTURE; i++) {
				// Create TimeSeries Container
				String containerName = "weather_station_" + (i + 1);
				// Get TimeSeries Container
				TimeSeries<InstrumentLog> logTs =
						store.getTimeSeries(containerName, InstrumentLog.class);

				// Drop TimeSeries Container
				store.dropTimeSeries(containerName);

				// Close TimeSeries Container
				logTs.close();
			}

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
