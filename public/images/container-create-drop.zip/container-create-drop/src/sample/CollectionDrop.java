package sample;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.WeatherStationLogic;

/**
 * Sample of Drop Collection.
 */
public class CollectionDrop {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			WeatherStationLogic wsLogic = new WeatherStationLogic();

			// Create Connection
			store = wsLogic.createGridStore();

			// Drop Collection
			store.dropCollection("weather_station");

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
