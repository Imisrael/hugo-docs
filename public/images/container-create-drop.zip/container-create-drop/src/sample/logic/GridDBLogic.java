package sample.logic;

import java.util.Properties;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.GridStoreFactory;

/**
 * This class provides a common logic to access the GridDB.
 */
public class GridDBLogic {

	/** count of Perfecture */
	public static final int JP_PREFECTURE = 47;

	/**
	 * This method creates an instance of the GridStore using the connection information of the
	 * GridDB.
	 *
	 * @return GridStore
	 * @throws GSException
	 */
	public GridStore createGridStore() throws GSException {
		// Set the Connection parameter for GridDB
		Properties props = new Properties();
		props.setProperty("host", "127.0.0.1");
		props.setProperty("port", "10001");
		props.setProperty("clusterName", "GSCLUSTER");
		props.setProperty("database", "public");
		props.setProperty("user", "admin");
		props.setProperty("password", "admin");
		GridStore store = GridStoreFactory.getInstance().getGridStore(props);

		return store;
	}
}
