package sample;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.InstrumentLogLogic;

/**
 * Sample of Create TimeSeries Container.
 */
public class TimeSeriesCreate {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			// Create TimeSeries Container
			logLogic.createTimeSeries(store);
			logLogic.createIndex(store);

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
