package sample;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.IndexType;

import sample.logic.WeatherStationLogic;
import sample.row.WeatherStation;

/**
 * Sample of Create Collection.
 */
public class CollectionCreate {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			WeatherStationLogic wsLogic = new WeatherStationLogic();

			// Create Connection
			store = wsLogic.createGridStore();

			// Create Collection
			Collection<String, WeatherStation> weatherStationCol =
					store.putCollection("weather_station", WeatherStation.class);

			// Create Index
			weatherStationCol.createIndex("id");
			weatherStationCol.createIndex("name", IndexType.TREE);

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
