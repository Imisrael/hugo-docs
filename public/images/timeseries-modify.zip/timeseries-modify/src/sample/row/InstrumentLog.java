package sample.row;

import java.sql.Blob;
import java.util.Date;

import com.toshiba.mwcloud.gs.RowKey;

/**
 * Class that represents the definition of the Row of Instrument log.
 */
public class InstrumentLog {
	/**
	 * Timestamp of log
	 */
	@RowKey
	public Date timestamp;

	/**
	 * ID of WeatherStation
	 */
	public String weatherStationId;

	/**
	 * Temperture of the measurement result
	 */
	public float temperture;

	/**
	 * Image data obtained by photographing the sky
	 */
	public Blob liveImage;
}
