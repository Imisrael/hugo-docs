package sample;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.InstrumentLogLogic;

/**
 * Sample of Drop TimeSeries Container.
 */
public class TimeSeriesIndex {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			// Note:
			// In fact the faster the search and there is an index,
			// search time was the same, because a small amount of data.
			// Therefore, in this sample only create and drop the index.

			// Create Index
			logLogic.createIndex(store);

			// Delete Index
			logLogic.dropIndex(store);

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
