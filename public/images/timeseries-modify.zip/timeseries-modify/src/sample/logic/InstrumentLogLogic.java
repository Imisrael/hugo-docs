package sample.logic;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import com.opencsv.CSVReader;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.TimeSeries;
import com.toshiba.mwcloud.gs.TimeUnit;
import com.toshiba.mwcloud.gs.TimestampUtils;

import sample.row.InstrumentLog;

/**
 * This class provides the ability to access the data of InstrumentLog.
 */
public class InstrumentLogLogic extends GridDBLogic {

	/**
	 * Create TimeSeries Container of InstrumentLog. If the TimeSeries Container dose not exists,
	 * crete a TimeSeries Container.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @return TimeSeries Container of InstrumentLog
	 * @throws GSException
	 */
	public void createTimeSeries(GridStore store) throws GSException {
		for (int i = 0; i < GridDBLogic.JP_PREFECTURE; i++) {
			// Create TimeSeries Container
			TimeSeries<InstrumentLog> ts =
					store.putTimeSeries("weather_station_" + (i + 1), InstrumentLog.class);

			// Close TimeSeries Container
			ts.close();
		}
	}

	/**
	 * Read the csv and returns list of InstrumentLog.
	 *
	 * @return list of InstrumentLog
	 * @throws IOException
	 * @throws ParseException
	 * @throws SQLException
	 * @throws SerialException
	 */
	public List<InstrumentLog> readCsv()
			throws IOException, ParseException, SerialException, SQLException {
		// Read CSV file
		List<InstrumentLog> logList = new ArrayList<InstrumentLog>();
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);
		String[] line = null;
		CSVReader reader = new CSVReader(new FileReader("data/instrument_log.csv"));

		try {
			while ((line = reader.readNext()) != null) {
				InstrumentLog log = new InstrumentLog();
				log.weatherStationId = line[0];
				log.timestamp = format.parse(line[1]);
				log.temperture = Float.valueOf(line[2]);

				// Write Blob data
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				String filePath = line[3];
				if ((filePath != null) && (!filePath.isEmpty())) {
					File imageFile = new File(filePath);
					if (imageFile.exists() && imageFile.isFile()) {
						InputStream inputStream = null;
						try {
							inputStream = new BufferedInputStream(new FileInputStream(imageFile));
							byte[] buff = new byte[1024];
							while ((inputStream.read(buff)) != -1) {
								outputStream.write(buff);
							}
						} finally {
							if (inputStream != null) {
								inputStream.close();
							}
						}
					}
				}
				log.liveImage = new SerialBlob(outputStream.toByteArray());

				logList.add(log);
			}

		} finally {
			reader.close();
		}
		return logList;
	}

	/**
	 * Register the list of InstrumentLog to GridDB.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param logList list of InstrumentLog
	 * @throws GSException
	 */
	public void registerTimeSeriesContainer(GridStore store, List<InstrumentLog> logList)
			throws GSException {
		for (InstrumentLog log : logList) {
			// Retrieve TimeSeries Container
			TimeSeries<InstrumentLog> logTs =
					store.putTimeSeries(log.weatherStationId, InstrumentLog.class);

			// Disable Auto Commit
			logTs.setAutoCommit(false);

			// Specify Time
			logTs.put(log.timestamp, log);

			// Specify Current Time
			// Comment out because the result would change on every execution
			// ts.append(log);

			// Instrument log timestamp is every 6 hours.
			// When the interpolation of 3 hours prior time to the log,
			// the temperature of the intermediate is registered
			Date medianTime = TimestampUtils.add(log.timestamp, -3, TimeUnit.HOUR);
			// Creating a TimeSeries Container when interpolating the values of temperature
			InstrumentLog medianLog = logTs.interpolate(medianTime, "temperture");
			// If there is no log, a NULL is returned before the interpolated time
			if (medianLog != null) {
				logTs.put(medianTime, medianLog);
			}

			// Commit
			logTs.commit();
		}
	}

	/**
	 * Create Index on the TimeSeries Container of InstrumentLog.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @throws GSException
	 */
	public void createIndex(GridStore store) throws GSException {
		for (int i = 0; i < GridDBLogic.JP_PREFECTURE; i++) {
			// Get TimeSeries Container
			TimeSeries<InstrumentLog> logTs =
					store.getTimeSeries("weather_station_" + (i + 1), InstrumentLog.class);

			try {
				// Create Index
				logTs.createIndex("temperture");
			} finally {
				// Close TimeSeries Container
				if (logTs != null) {
					logTs.close();
				}
			}
		}
	}

	/**
	 * Delete Index on the TimeSeries Container of InstrumentLog.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @throws GSException
	 */
	public void dropIndex(GridStore store) throws GSException {
		for (int i = 0; i < GridDBLogic.JP_PREFECTURE; i++) {
			// Get TimeSeries Container
			TimeSeries<InstrumentLog> logTs =
					store.getTimeSeries("weather_station_" + (i + 1), InstrumentLog.class);

			try {
				// Drop Index
				logTs.dropIndex("temperture");
			} finally {
				// Close TimeSeries Container
				if (logTs != null) {
					logTs.close();
				}
			}
		}
	}

	/**
	 * Make a hexadecimal string from blob data.
	 *
	 * @param blob data of binary
	 * @return hexadecimal string
	 * @throws SQLException
	 */
	public static String makeByteString(Blob blob) throws SQLException {
		byte[] blobData = blob.getBytes(1, (int) (blob.length()));
		StringBuilder byteText = new StringBuilder();
		if (blobData.length > 0) {
			for (byte blobByte : blobData) {
				byteText.append(String.format("0x%02x ", blobByte));
			}
		} else {
			byteText.append("None");
		}
		return byteText.toString();
	}
}
