package sample;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.TimeSeries;
import com.toshiba.mwcloud.gs.TimeSeriesProperties;

import sample.logic.InstrumentLogLogic;
import sample.row.AnotherInstrumentLog;
import sample.row.InstrumentLog;

/**
 * Sample of Row difinition modification.
 */
public class TimeSeriesModify {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			try {
				// Create another schema TimeSeries Container
				TimeSeries<AnotherInstrumentLog> anotherTs =
						store.putTimeSeries("weather_station_1", AnotherInstrumentLog.class);
			} catch (GSException e) {
				// If omit the parameter:modifiable, an exception occurs
				System.out.println("Exceptions as expected");
				e.printStackTrace();
			}

			// Create another schema TimeSeries Container
			TimeSeriesProperties timeProp = new TimeSeriesProperties();
			TimeSeries<AnotherInstrumentLog> anotherTs = store.putTimeSeries("weather_station_1",
					AnotherInstrumentLog.class, timeProp, true);

			// Exceptions not throw

			// Repair TimeSeries Container
			anotherTs.close();
			TimeSeries<InstrumentLog> ts =
					store.putTimeSeries("weather_station_1", InstrumentLog.class, timeProp, true);
			ts.close();

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
