package sample;

import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.ContainerInfo;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Row;
import com.toshiba.mwcloud.gs.TimeSeries;

import sample.logic.GridDBLogic;
import sample.logic.InstrumentLogLogic;
import sample.row.InstrumentLog;
import sample.row.WeatherStation;

/**
 * Sample of multiput operations
 */
public class MultiPut {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Create InstrumentLog Container and Row
			store.putTimeSeries("weather_station_99", InstrumentLog.class);

			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);

			// multiput Rows
			Map<String, List<Row>> containerRowsMap = new HashMap<>();

			// Create WeatherStation Row
			Row wsRow =
					createWeatherStationRow(store, "99", "new WeatherStation", 45.26, 75.42, true);

			// Create InstrumentLog Row
			Row logRow = createInstrumentLogRow(store, format.parse("2016/07/03 12:00:00"),
					"weather_station_99", 40.5f,
					new SerialBlob(new byte[] {0x10, 0x11, 0x12, 0x13, 0x14, 0x15}));

			// Add multiput value
			List<Row> wsRowList = new ArrayList<>();
			wsRowList.add(wsRow);
			containerRowsMap.put("weather_station", wsRowList);
			List<Row> logRowList = new ArrayList<>();
			logRowList.add(logRow);
			containerRowsMap.put("weather_station_99", logRowList);

			// Register by multiput
			store.multiPut(containerRowsMap);

			// Retrieve Row of registered
			showWeatherStation(store, "99");

			showInstrumentLog(store, format.parse("2016/07/03 12:00:00"));

		} catch (GSException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SerialException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

	/**
	 * create Row of WeatherStation
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param id ID of WeatherStation
	 * @param name Name of WeatherStation
	 * @param latitude Installation Latitude
	 * @param longitude Installation Longitude
	 * @param hasCamera Camera exists or not
	 * @return Row of WeatherStation
	 * @throws GSException
	 */
	private static Row createWeatherStationRow(GridStore store, String id, String name,
			double latitude, double longitude, boolean hasCamera) throws GSException {
		// Create WeatherStation Row
		ContainerInfo wsContainerInfo = store.getContainerInfo("weather_station");
		Row wsRow = store.createRow(wsContainerInfo);

		// Set by specifying the index of the order of definition of the WeatherStation class
		// ID
		wsRow.setString(0, id);
		// Name
		wsRow.setString(1, name);
		// Latitude
		wsRow.setDouble(2, latitude);
		// Longitude
		wsRow.setDouble(3, longitude);
		// hasCamera
		wsRow.setBool(4, hasCamera);

		return wsRow;
	}

	/**
	 * Create Row of InstrumentLogRow
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param timestamp Timestamp of log
	 * @param weatherStationId ID of WeatherStation
	 * @param temperture Temperture of the measurement result
	 * @param liveImage Image data obtained by photographing the sky
	 * @return Row of InstrumentLogRow
	 * @throws GSException
	 * @throws ParseException
	 * @throws SerialException
	 * @throws SQLException
	 */
	private static Row createInstrumentLogRow(GridStore store, Date timestamp,
			String weatherStationId, float temperture, Blob liveImage)
			throws GSException, ParseException, SerialException, SQLException {
		// Create InstrumentLogRow Row
		ContainerInfo logContainerInfo = store.getContainerInfo("weather_station_99");
		Row logRow = store.createRow(logContainerInfo);

		// Set by specifying the index of the order of definition of the InstrumentLog class
		// Timestamp
		logRow.setTimestamp(0, timestamp);
		// ID of WeatherStation
		logRow.setString(1, weatherStationId);
		// Temperture
		logRow.setFloat(2, temperture);
		// Live Image data
		logRow.setBlob(3, liveImage);

		return logRow;
	}

	/**
	 * Show WeatherStation Row
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param key Row key of WeatherStation
	 * @throws GSException
	 */
	private static void showWeatherStation(GridStore store, String rowKey) throws GSException {
		System.out.println("#####  WeatherStation:");
		System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
		// Get WeatherStation
		Collection<String, WeatherStation> weatherStationCol =
				store.getCollection("weather_station", WeatherStation.class);
		WeatherStation weatherStation = weatherStationCol.get(rowKey);

		System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s", weatherStation.id,
				weatherStation.name, weatherStation.latitude, weatherStation.longitude,
				weatherStation.hasCamera));
	}

	/**
	 * Show InstrumentLog Row
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param rowKey Row key of InstrumentLog
	 * @throws GSException
	 * @throws ParseException
	 * @throws SQLException
	 */
	private static void showInstrumentLog(GridStore store, Date rowKey)
			throws GSException, ParseException, SQLException {
		System.out.println("#####  InstrumentLog:");
		System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture\tLive Image");
		TimeSeries<InstrumentLog> logTs =
				store.getTimeSeries("weather_station_99", InstrumentLog.class);
		InstrumentLog log = logTs.get(rowKey);
		// Make a displayable byte string
		String byteText = InstrumentLogLogic.makeByteString(log.liveImage);

		System.out.println(String.format("%s\t%-20s\t%-10s\t%s", log.timestamp,
				log.weatherStationId, log.temperture, byteText));
	}

}
