package sample;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.toshiba.mwcloud.gs.AggregationResult;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Query;
import com.toshiba.mwcloud.gs.RowSet;
import com.toshiba.mwcloud.gs.TimeSeries;
import com.toshiba.mwcloud.gs.TimestampUtils;

import sample.logic.GridDBLogic;
import sample.row.InstrumentLog;

/**
 * Sample of multiquery operations
 */
public class MultiQuery {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Create query list
			List<Query<?>> queries = new ArrayList<>();

			for (int i = 0; i < 2; i++) {
				// Get InstrumentLog
				TimeSeries<InstrumentLog> logTs =
						store.getTimeSeries("weather_station_" + (i + 1), InstrumentLog.class);

				// add query list
				queries.addAll(createQueries(logTs));
			}

			// Execute Multi Query
			store.fetchAll(queries);

			// Retrieve reulsts
			for (Query<?> query : queries) {
				RowSet<?> rowSet = query.getRowSet();
				while (rowSet.hasNext()) {
					Object rowObj = rowSet.next();
					if (rowObj instanceof AggregationResult) {
						// When retrieve AggregationResult
						AggregationResult aggregation = (AggregationResult) rowObj;
						System.out.println("AggregationResult:" + aggregation.getDouble());

					} else if (rowObj instanceof InstrumentLog) {
						// When retrieve InstrumentLog
						InstrumentLog log = (InstrumentLog) rowObj;
						System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp,
								log.weatherStationId, log.temperture));

					} else {
						// Do not reach in this sample
						System.out.println(rowObj);
					}
				}
			}

		} catch (GSException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

	/**
	 * Create Queries for multiquery
	 *
	 * @param logTs TimeSeries of InstrumentLog
	 * @return list of queries
	 * @throws ParseException
	 * @throws GSException
	 */
	private static List<Query<?>> createQueries(TimeSeries<InstrumentLog> logTs)
			throws ParseException, GSException {
		// Set TimeSeries conditions
		Date start = TimestampUtils.getFormat().parse("2016-07-01T06:00:00Z");
		Date end = TimestampUtils.getFormat().parse("2016-07-01T18:00:00Z");

		List<Query<?>> queries = new ArrayList<>();

		// Get Max Temperture
		String maxTempertureTql = String.format(
				"SELECT MAX(temperture) WHERE"
						+ " TIMESTAMP('%s') < timestamp AND timestamp < TIMESTAMP('%s')",
				TimestampUtils.format(start), TimestampUtils.format(end));
		Query<AggregationResult> maxTempertureQuery =
				logTs.query(maxTempertureTql, AggregationResult.class);

		// Get Min Temperture
		String minTempertureTql = String.format(
				"SELECT MIN(temperture) WHERE"
						+ " TIMESTAMP('%s') < timestamp AND timestamp < TIMESTAMP('%s')",
				TimestampUtils.format(start), TimestampUtils.format(end));
		Query<AggregationResult> minTempertureQuery =
				logTs.query(minTempertureTql, AggregationResult.class);

		// Get Average
		String avgTempertureTql = String.format(
				"SELECT AVG(temperture) WHERE"
						+ " TIMESTAMP('%s') < timestamp AND timestamp < TIMESTAMP('%s')",
				TimestampUtils.format(start), TimestampUtils.format(end));
		Query<AggregationResult> avgTempertureQuery =
				logTs.query(avgTempertureTql, AggregationResult.class);

		// Retrieve by time range
		Query<InstrumentLog> timeRangeQuery = logTs.query(start, end);

		// Add Query
		queries.add(maxTempertureQuery);
		queries.add(minTempertureQuery);
		queries.add(avgTempertureQuery);
		queries.add(timeRangeQuery);

		return queries;
	}

}
