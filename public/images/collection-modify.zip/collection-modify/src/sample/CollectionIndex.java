package sample;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.IndexType;

import sample.logic.WeatherStationLogic;
import sample.row.WeatherStation;

/**
 * Sample of Index creation and deletion
 */
public class CollectionIndex {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			WeatherStationLogic wsLogic = new WeatherStationLogic();

			// Create Connection
			store = wsLogic.createGridStore();

			// Get Collection
			Collection<String, WeatherStation> weatherStationCol =
					store.getCollection("weather_station", WeatherStation.class);

			// Note:
			// In fact the faster the search and there is an index,
			// search time was the same, because a small amount of data.
			// Therefore, in this sample only create and drop the index.

			// Create Index
			weatherStationCol.createIndex("id");
			weatherStationCol.createIndex("name", IndexType.TREE);

			// Drop Index
			weatherStationCol.dropIndex("id");
			weatherStationCol.dropIndex("name");

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
