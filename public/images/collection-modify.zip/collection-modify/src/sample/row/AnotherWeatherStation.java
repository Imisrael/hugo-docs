package sample.row;

import com.toshiba.mwcloud.gs.RowKey;

public class AnotherWeatherStation {
	/**
	 * ID of WeatherStation
	 */
	@RowKey
	public String id;

	/**
	 * Name of WeatherStation
	 */
	public String name;

	/**
	 * Installation Latitude
	 */
	public double latitude;

	/**
	 * Installation Longitude
	 */
	public double longitude;

	/**
	 * Camera exists or not
	 */
	public boolean hasCamera;

	/**
	 * Added field to WeatherStation
	 */
	public String description;
}
