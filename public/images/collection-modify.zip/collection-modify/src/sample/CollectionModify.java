package sample;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.WeatherStationLogic;
import sample.row.AnotherWeatherStation;
import sample.row.WeatherStation;

/**
 * Sample of Row difinition modification.
 */
public class CollectionModify {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			WeatherStationLogic wsLogic = new WeatherStationLogic();

			// Create Connection
			store = wsLogic.createGridStore();

			try {
				// Create another schema Collection
				Collection<String, AnotherWeatherStation> anotherWeatherStationCol =
						store.putCollection("weather_station", AnotherWeatherStation.class);

			} catch (GSException e) {
				// If omit the parameter:modifiable, an exception occurs
				System.out.println("Exceptions as expected");
				e.printStackTrace();
			}

			// Create another schema Collection
			Collection<String, AnotherWeatherStation> anotherWeatherStationCol =
					store.putCollection("weather_station", AnotherWeatherStation.class, true);

			// Exceptions not occurs

			// Repair Collection schema
			anotherWeatherStationCol.close();
			Collection<String, WeatherStation> weatherStationCol =
					store.putCollection("weather_station", WeatherStation.class, true);
			weatherStationCol.close();

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
