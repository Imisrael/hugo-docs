package sample;

import java.util.Properties;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.GridStoreFactory;

import sample.row.WeatherStation;

public class FirstGridDB {

	public static void main(String[] args) throws GSException {
		// Set the Connection parameter for GridDB
		Properties props = new Properties();
		props.setProperty("host", "127.0.0.1");
		props.setProperty("port", "10001");
		props.setProperty("clusterName", "GSCLUSTER");
		props.setProperty("database", "public");
		props.setProperty("user", "admin");
		props.setProperty("password", "admin");
		GridStore store = GridStoreFactory.getInstance().getGridStore(props);

		// Create Collection
		Collection<String, WeatherStation> weatherStationCol =
				store.putCollection("weather_station", WeatherStation.class);

		// Set the value to Row data
		WeatherStation weatherStation1 = new WeatherStation();
		weatherStation1.id = "1";
		weatherStation1.name = "WeatherStation 01";
		weatherStation1.latitude = 35.68944;
		weatherStation1.longitude = 139.69167;
		weatherStation1.hasCamera = true;

		WeatherStation weatherStation2 = new WeatherStation();
		weatherStation2.id = "2";
		weatherStation2.name = "WeatherStation 02";
		weatherStation2.latitude = 35.02139;
		weatherStation2.longitude = 135.75556;
		weatherStation2.hasCamera = false;

		// Register Collection
		weatherStationCol.put(weatherStation1);
		weatherStationCol.put(weatherStation2);

		// Retrieve Collection
		System.out.println("get by key");
		System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
		weatherStationCol = store.getCollection("weather_station", WeatherStation.class);

		for (int i = 0; i < 2; i++) {
			WeatherStation weatherStation = weatherStationCol.get(String.valueOf(i + 1));
			System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s", weatherStation.id,
					weatherStation.name, weatherStation.latitude, weatherStation.longitude,
					weatherStation.hasCamera));
		}

		// Close Connection
		store.close();
	}
}
