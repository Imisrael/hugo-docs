package sample.row;

import com.toshiba.mwcloud.gs.RowKey;

/**
 * Class that represents the definition of the schema.
 */
public class WeatherStation {
	/**
	 * ID of WeatherStation
	 */
	@RowKey
	public String id;

	/**
	 * Name of WeatherStation
	 */
	public String name;

	/**
	 * Installation Latitude
	 */
	public double latitude;

	/**
	 * Installation Longitude
	 */
	public double longitude;

	/**
	 * Camera exists or not
	 */
	public boolean hasCamera;
}
