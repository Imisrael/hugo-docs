package sample;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.toshiba.mwcloud.gs.Aggregation;
import com.toshiba.mwcloud.gs.AggregationResult;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Query;
import com.toshiba.mwcloud.gs.RowSet;
import com.toshiba.mwcloud.gs.TimeOperator;
import com.toshiba.mwcloud.gs.TimeSeries;
import com.toshiba.mwcloud.gs.TimeUnit;
import com.toshiba.mwcloud.gs.TimestampUtils;

import sample.logic.GridDBLogic;
import sample.logic.InstrumentLogLogic;
import sample.row.InstrumentLog;

/**
 * Sample of data retrieving of Collection.
 */
public class TimeSeriesRetrieve {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);

			// Retrieve TimeSeries Container
			for (int i = 0; i < GridDBLogic.JP_PREFECTURE; i++) {
				String containerName = "weather_station_" + (i + 1);
				// Get TimeSeries Container
				TimeSeries<InstrumentLog> logTs =
						store.getTimeSeries(containerName, InstrumentLog.class);

				System.out.println(containerName + " ################");
				System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture");

				// Specify Time
				retrieveByTime(logTs, format);

				// Specify Time Range
				retrieveByTimeRange(logTs, format);

				// Specify the TimeOperator
				retrieveByTimeOperator(logTs, format);

				// Average Temperature
				aggregateAverage(logTs, format);

				logTs.close();
			}
		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} catch (ParseException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw other than,
			// because the change of the previous commit is not canceled,
			// if necessary, to call abort()

			// In auto-commit mode on, if the GSException throw other than,
			// because the change of the previous commit is canceled,
			// it is not necessary to call abort()
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

	/**
	 * Retrieve InstrumentLog by specifying the time.
	 *
	 * @param logTs InstrumentLog of TimeSeries
	 * @param format It is used to specify a log time
	 * @throws GSException
	 * @throws ParseException
	 */
	private static void retrieveByTime(TimeSeries<InstrumentLog> logTs, SimpleDateFormat format)
			throws GSException, ParseException {
		// Specify Time
		InstrumentLog log = logTs.get(format.parse("2016/07/02 12:00"));
		System.out.println("get by Time");
		System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp, log.weatherStationId,
				log.temperture));
	}

	/**
	 * Retrieve InstrumentLog by specifying the range of time.
	 *
	 * @param logTs InstrumentLog of TimeSeries
	 * @param format It is used to specify a log time
	 * @throws GSException
	 * @throws ParseException
	 * @throws SQLException
	 */
	private static void retrieveByTimeRange(TimeSeries<InstrumentLog> logTs,
			SimpleDateFormat format) throws GSException, ParseException, SQLException {
		// Specify Time Range
		System.out.println("get by Time Range");
		Date start = format.parse("2016/07/02 9:00");
		Date end = TimestampUtils.add(start, 6, TimeUnit.HOUR);

		Query<InstrumentLog> query = logTs.query(start, end);
		// fetch row
		RowSet<InstrumentLog> rowSet = query.fetch();
		while (rowSet.hasNext()) {
			InstrumentLog log = rowSet.next();
			System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture\tLive Image");
			System.out.println(String.format("%s\t%-20s\t%-10s\t%s", log.timestamp,
					log.weatherStationId, log.temperture));
		}
	}

	/**
	 * Retrieve InstrumentLog by specifying base of time and TimeOperator.
	 *
	 * @param logTs InstrumentLog of TimeSeries
	 * @param format It is used to specify a log time
	 * @throws GSException
	 * @throws ParseException
	 */
	private static void retrieveByTimeOperator(TimeSeries<InstrumentLog> logTs,
			SimpleDateFormat format) throws GSException, ParseException {
		// Specify the next time, including a specified time
		InstrumentLog log = logTs.get(format.parse("2016/07/02 12:00"), TimeOperator.NEXT);
		System.out.println("get by Next Time");
		System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp, log.weatherStationId,
				log.temperture));

		// Specify the next time
		log = logTs.get(format.parse("2016/07/02 12:00"), TimeOperator.NEXT_ONLY);
		System.out.println("get by NextOnly Time");
		System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp, log.weatherStationId,
				log.temperture));

		// Specify the previous time, including a specified time
		log = logTs.get(format.parse("2016/07/02 12:00"), TimeOperator.PREVIOUS);
		System.out.println("get by Previous Time");
		System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp, log.weatherStationId,
				log.temperture));

		// Specify the previous time
		log = logTs.get(format.parse("2016/07/02 12:00"), TimeOperator.PREVIOUS_ONLY);
		System.out.println("get by PreviousOnly Time");
		System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp, log.weatherStationId,
				log.temperture));
	}

	/**
	 * Aggregate the average temperature in the InstrumentLog.
	 *
	 * @param logTs InstrumentLog of TimeSeries
	 * @param format It is used to specify a log time
	 * @throws GSException
	 * @throws ParseException
	 */
	private static void aggregateAverage(TimeSeries<InstrumentLog> logTs, SimpleDateFormat format)
			throws GSException, ParseException {
		// Average Temperature
		Date start = format.parse("2016/07/01 12:00");
		Date end = format.parse("2016/07/02 9:00");
		AggregationResult aggrResult =
				logTs.aggregate(start, end, "temperture", Aggregation.AVERAGE);
		System.out.println("Average Temperature:" + aggrResult.getDouble() + "\n");
	}

}
