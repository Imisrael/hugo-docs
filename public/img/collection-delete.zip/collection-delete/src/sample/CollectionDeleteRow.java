package sample;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.WeatherStationLogic;
import sample.row.WeatherStation;

/**
 * Sample of Delete Row of Collection
 */
public class CollectionDeleteRow {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			WeatherStationLogic wsLogic = new WeatherStationLogic();

			// Create Connection
			store = wsLogic.createGridStore();

			// Get Collection
			Collection<String, WeatherStation> weatherStationCol =
					store.getCollection("weather_station", WeatherStation.class);

			// Delete Row
			boolean deleteSucceed = weatherStationCol.remove("1");
			System.out.println("Delete Succeed:" + deleteSucceed);

			System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
			for (int i = 0; i < WeatherStationLogic.JP_PREFECTURE; i++) {
				// Retrieve row by key
				WeatherStation weatherStation = weatherStationCol.get(String.valueOf(i + 1));
				if (weatherStation != null) {
					System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s",
							weatherStation.id, weatherStation.name, weatherStation.latitude,
							weatherStation.longitude, weatherStation.hasCamera));
				} else {
					System.out.println(String.format("ID:%s is not exist", (i + 1)));
				}
			}

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
