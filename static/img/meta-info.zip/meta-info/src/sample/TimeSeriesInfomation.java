package sample;

import java.util.Set;

import com.toshiba.mwcloud.gs.ContainerInfo;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.TimeSeriesProperties;

import sample.logic.GridDBLogic;

/**
 * Sample of TimeSeriesProperties has infomation and,
 */
public class TimeSeriesInfomation {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic logic = new GridDBLogic();

			// Create Connection
			store = logic.createGridStore();

			// Get Container Infomation
			ContainerInfo containerInfo = store.getContainerInfo("weather_station_1");
			// Get TimeSeries Properties
			TimeSeriesProperties tsProp = containerInfo.getTimeSeriesProperties();

			// Show TimeSeriesProperties has values
			System.out.println("########## TimeSeriesProperties");
			System.out.println("CompressionMethod:" + tsProp.getCompressionMethod());
			System.out.println(
					"CompressionRate(temperture):" + tsProp.getCompressionRate("temperture"));
			System.out.println(
					"CompressionSpan(temperture):" + tsProp.getCompressionSpan("temperture"));
			System.out.println(
					"CompressionWidth(temperture):" + tsProp.getCompressionWidth("temperture"));
			System.out.println("CompressionWindowSize:" + tsProp.getCompressionWindowSize());
			System.out
					.println("CompressionWindowSizeUnit:" + tsProp.getCompressionWindowSizeUnit());
			System.out.println("ExpirationDivisionCount:" + tsProp.getExpirationDivisionCount());
			System.out.println("RowExpirationTime:" + tsProp.getRowExpirationTime());
			System.out.println("RowExpirationTimeUnit:" + tsProp.getRowExpirationTimeUnit());
			System.out.println("SpecifiedColumns:");
			Set<String> specifiedColumns = tsProp.getSpecifiedColumns();
			for (String specifiedColumn : specifiedColumns) {
				System.out.println(specifiedColumn);
			}
			System.out.println("isCompressionRelative(temperture):"
					+ tsProp.isCompressionRelative("temperture"));

		} catch (GSException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
