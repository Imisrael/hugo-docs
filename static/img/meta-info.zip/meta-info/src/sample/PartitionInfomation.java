package sample;

import java.net.InetAddress;
import java.util.List;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.PartitionController;

import sample.logic.GridDBLogic;

/**
 * Sample of PartitionInfomation
 */
public class PartitionInfomation {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic logic = new GridDBLogic();

			// Create Connection
			store = logic.createGridStore();

			// Get PartitionController
			PartitionController partitionController = store.getPartitionController();

			// Show PartitionController has Infomation
			int partitionCount = partitionController.getPartitionCount();
			System.out.println("Partition Count:" + partitionCount);
			for (int i = 0; i < partitionCount; i++) {
				System.out.println("Partition:" + (i + 1) + " ##########");
				System.out.println("Owner Node:" + partitionController.getOwnerHost(i));
				System.out.println("BackupHosts:" + partitionController.getBackupHosts(i));
				List<InetAddress> nodeHosts = partitionController.getHosts(i);
				for (InetAddress nodeHost : nodeHosts) {
					System.out.println("Node Host" + nodeHost);
				}
				System.out.println("ContainerCount:" + partitionController.getContainerCount(i));
				List<String> containerNames = partitionController.getContainerNames(i, 0, null);
				for (String containerName : containerNames) {
					System.out.println("Container Name:" + containerName);
				}
			}

			System.out.println("\nWeatherStation Partition:"
					+ partitionController.getPartitionIndexOfContainer("weather_station"));
		} catch (GSException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
