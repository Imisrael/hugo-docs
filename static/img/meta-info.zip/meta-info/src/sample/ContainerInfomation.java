package sample;

import com.toshiba.mwcloud.gs.ContainerInfo;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.GridDBLogic;

/**
 * Sample of Show ContainerInfo has values
 */
public class ContainerInfomation {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic logic = new GridDBLogic();

			// Create Connection
			store = logic.createGridStore();

			// Get Container Infomation
			ContainerInfo containerInfo = store.getContainerInfo("weather_station");
			System.out.println("WeatherStation Container Infomation ##########");
			System.out.println("Container Name:" + containerInfo.getName());
			System.out.println("Container Type:" + containerInfo.getType());
			System.out.println("Column Count:" + containerInfo.getColumnCount());
			System.out.println("DataAffinity:" + containerInfo.getDataAffinity());
			System.out.println("Column Order Ignorable:" + containerInfo.isColumnOrderIgnorable());
			System.out.println("RowKeyAssigned:" + containerInfo.isRowKeyAssigned());

		} catch (GSException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
