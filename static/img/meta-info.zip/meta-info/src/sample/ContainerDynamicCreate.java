package sample;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import com.toshiba.mwcloud.gs.ColumnInfo;
import com.toshiba.mwcloud.gs.Container;
import com.toshiba.mwcloud.gs.ContainerInfo;
import com.toshiba.mwcloud.gs.ContainerType;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GSType;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.IndexType;
import com.toshiba.mwcloud.gs.Row;

import sample.logic.GridDBLogic;

/**
 * Sample of How to create Container using ContainerInfo and ColumnInfo
 */
public class ContainerDynamicCreate {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic logic = new GridDBLogic();

			// Create Connection
			store = logic.createGridStore();

			// Create ContainerInfo
			ContainerInfo containerInfo = createContainerInfo();

			// Create Container
			Container<String, Row> dynamicWeatherStaton =
					store.putContainer("dynamic_weather_station", containerInfo, true);

			// Register Row
			registerRow(containerInfo, dynamicWeatherStaton);

			dynamicWeatherStaton.close();

			// Re-Get Container
			Container<String, Row> weatherStationCol =
					store.getContainer("dynamic_weather_station");

			// Retrieve Container
			System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
			for (int i = 0; i < 5; i++) {
				Row row = weatherStationCol.get(String.valueOf(i + 1));
				// Get by specifying the index of the order of definition of the WeatherStation
				// class
				String id = row.getString(0);
				String name = row.getString(1);
				double latitude = row.getDouble(2);
				double longitude = row.getDouble(3);
				boolean hasCamera = row.getBool(4);

				System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s", id, name,
						latitude, longitude, hasCamera));
			}

		} catch (GSException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

	/**
	 * Create ContainerInfo for Schema Definition.
	 *
	 * @return Defined ContainerInfo
	 */
	private static ContainerInfo createContainerInfo() {
		List<ColumnInfo> columnInfoList = new ArrayList<ColumnInfo>();

		// Define Container Key and Index
		EnumSet<IndexType> indexSet = EnumSet.of(IndexType.HASH);
		ColumnInfo keyColumn = new ColumnInfo("id", GSType.STRING, indexSet);
		columnInfoList.add(keyColumn);

		// Define Container Columns
		columnInfoList.add(new ColumnInfo("name", GSType.STRING));
		columnInfoList.add(new ColumnInfo("latitude", GSType.DOUBLE));
		columnInfoList.add(new ColumnInfo("longitude", GSType.DOUBLE));
		columnInfoList.add(new ColumnInfo("hasCamera", GSType.BOOL));

		// Define Container
		ContainerInfo containerInfo = new ContainerInfo("dynamic_weather_station",
				ContainerType.COLLECTION, columnInfoList, true);
		return containerInfo;
	}

	/**
	 * Register using Row API
	 *
	 * @param containerInfo Definition of Container
	 * @param dynamicWeatherStaton Registration target of Container
	 * @throws GSException
	 */
	private static void registerRow(ContainerInfo containerInfo,
			Container<String, Row> dynamicWeatherStaton) throws GSException {
		int columnCount = containerInfo.getColumnCount();
		for (int rowIndex = 0; rowIndex < 5; rowIndex++) {
			Row row = dynamicWeatherStaton.createRow();
			for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
				ColumnInfo columnInfo = containerInfo.getColumnInfo(columnIndex);
				GSType columnType = columnInfo.getType();
				Object value = null;
				switch (columnType) {
					case STRING:
						if ("id".equals(columnInfo.getName())) {
							value = String.valueOf(rowIndex + 1);
						} else {
							value = "name_" + (rowIndex + 1) + "_" + columnIndex;
						}
						break;
					case DOUBLE:
						value = Double.valueOf(rowIndex + 1 + columnIndex);
						break;
					case BOOL:
						value = true;
						break;
					// Omitted other types
					default:
						break;
				}

				row.setValue(columnIndex, value);
			}

			// Register Row
			dynamicWeatherStaton.put(row);
		}
	}

}
