package sample;

import java.sql.Blob;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Row;
import com.toshiba.mwcloud.gs.RowKeyPredicate;

import sample.logic.GridDBLogic;
import sample.logic.InstrumentLogLogic;
import sample.row.WeatherStation;

/**
 * Sample of multiget operations
 */
public class MultiGet {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Get Collection
			Collection<String, WeatherStation> weatherStationCol =
					store.getCollection("weather_station", WeatherStation.class);

			// Create MultiGet parameters
			Map<String, RowKeyPredicate<?>> containerPredicateMap =
					careteMultiGetCondition(weatherStationCol);

			// Get by multiget
			Map<String, List<Row>> multiGetResults = store.multiGet(containerPredicateMap);

			// Retrieve results
			for (Entry<String, List<Row>> multiGetResult : multiGetResults.entrySet()) {
				// Container Name
				String containerName = multiGetResult.getKey();
				System.out.println(containerName + " ################");

				if ("weather_station".equals(containerName)) {
					// Retrieve WeatherStation Rows
					retieveWeatherStationRows(multiGetResult);
				} else {
					// Retrieve InstrumentLog Rows
					retrieveInstrumentLogRows(multiGetResult);
				}
			}

		} catch (GSException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

	/**
	 * Create parameter of multiget.
	 *
	 * @param weatherStationCol Collecton of WeatherSation
	 * @return the map for use parameter of multiget.
	 * @throws GSException
	 * @throws ParseException
	 */
	private static Map<String, RowKeyPredicate<?>> careteMultiGetCondition(
			Collection<String, WeatherStation> weatherStationCol)
			throws GSException, ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);

		// Create search condition of WeatherStation
		RowKeyPredicate<String> wsRowKeys = RowKeyPredicate.create(String.class);

		// Create multiget condition
		Map<String, RowKeyPredicate<?>> containerPredicateMap = new HashMap<>();
		for (int i = 0; i < 2; i++) {
			// Get WeatherStation
			WeatherStation weatherStation = weatherStationCol.get(String.valueOf(i + 1));
			wsRowKeys.add(weatherStation.id);

			// Create search condition of InstrumentLog
			RowKeyPredicate<Date> logRowKeys = RowKeyPredicate.create(Date.class);
			// Set TimeSeries Rows Timestamp
			logRowKeys.setStart(format.parse("2016/07/02 6:00"));
			logRowKeys.setFinish(format.parse("2016/07/02 12:00"));
			// Add ContainerName and RowKeyParedicate
			String logContainerName = "weather_station_" + weatherStation.id;

			// Put multiget condition
			containerPredicateMap.put(logContainerName, logRowKeys);
		}
		// Put multiget condition
		String wsContainerName = "weather_station";
		containerPredicateMap.put(wsContainerName, wsRowKeys);
		return containerPredicateMap;
	}

	/**
	 * Retrieve WeatherStation value from Row
	 *
	 * @param multiGetResult Result of multiget
	 * @throws GSException
	 */
	private static void retieveWeatherStationRows(Entry<String, List<Row>> multiGetResult)
			throws GSException {
		System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
		List<Row> rowList = multiGetResult.getValue();
		for (Row row : rowList) {
			// Get by specifying the index of the order of definition of the WeatherStation class
			String id = row.getString(0);
			String name = row.getString(1);
			double latitude = row.getDouble(2);
			double longitude = row.getDouble(3);
			boolean hasCamera = row.getBool(4);

			System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s", id, name, latitude,
					longitude, hasCamera));
		}
	}

	/**
	 * Retrieve InstrumentLog value from Row
	 *
	 * @param multiGetResult Result of multiget
	 * @throws GSException
	 * @throws SQLException
	 */
	private static void retrieveInstrumentLogRows(Entry<String, List<Row>> multiGetResult)
			throws GSException, SQLException {
		System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture\tLive Image");
		List<Row> rowList = multiGetResult.getValue();
		for (Row row : rowList) {
			// Get by specifying the index of the order of definition of the InstrumentLog class
			Date logTimestamp = row.getTimestamp(0);
			String weatherStationId = row.getString(1);
			float temperture = row.getFloat(2);
			Blob liveImage = row.getBlob(3);
			String byteText = InstrumentLogLogic.makeByteString(liveImage);
			System.out.println(String.format("%s\t%-20s\t%-10s\t%s", logTimestamp, weatherStationId,
					temperture, byteText));
		}
	}

}
