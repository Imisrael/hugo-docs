package sample;

import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.EnumSet;
import java.util.Locale;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.TimeSeries;
import com.toshiba.mwcloud.gs.TriggerInfo;
import com.toshiba.mwcloud.gs.TriggerInfo.EventType;
import com.toshiba.mwcloud.gs.TriggerInfo.Type;

import sample.logic.GridDBLogic;
import sample.row.InstrumentLog;

/**
 * Sample of Trigger to notify the JMS
 */
public class TriggerJms {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Create Trigger Settings
			TriggerInfo trigger = new TriggerInfo();
			trigger.setName("InstrumentLogJMSTrigger");
			trigger.setType(Type.JMS);
			trigger.setJMSDestinationType("queue");
			trigger.setJMSDestinationName("jms/griddb");
			trigger.setTargetEvents(EnumSet.of(EventType.PUT));
			trigger.setUser("admin");
			trigger.setPassword("admin");
			trigger.setURI(URI.create("http://192.168.11.11:7676/"));

			// Get TimeSeries Container
			TimeSeries<InstrumentLog> logTs =
					store.getTimeSeries("weather_station_1", InstrumentLog.class);

			logTs.createTrigger(trigger);

			// Update Data for call Trigger
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);
			InstrumentLog log = logTs.get(format.parse("2016/07/02 12:00"));
			log.temperture = 90;
			logTs.put(log);

		} catch (GSException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
