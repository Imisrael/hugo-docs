package sample;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.InstrumentLogLogic;
import sample.row.InstrumentLog;

/**
 * Sample of data registration of TimeSeries Container.
 */
public class TimeSeriesRegister {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			// Read InstrumentLog data from csv
			List<InstrumentLog> logList = logLogic.readCsv();
			// Register TimeSeries Container
			logLogic.registerTimeSeriesContainer(store, logList);

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} catch (SQLException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw other than,
			// because the change of the previous commit is not canceled,
			// if necessary, to call abort()

			// In auto-commit mode on, if the GSException throw other than,
			// because the change of the previous commit is canceled,
			// it is not necessary to call abort()
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
