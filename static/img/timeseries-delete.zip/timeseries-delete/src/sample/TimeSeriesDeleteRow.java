package sample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.TimeSeries;

import sample.logic.InstrumentLogLogic;
import sample.row.InstrumentLog;

/**
 * Sample of Delete Row of TimeSeries Container
 */
public class TimeSeriesDeleteRow {

	public static void main(String[] args) throws ParseException, GSException {
		GridStore store = null;
		try {
			InstrumentLogLogic logLogic = new InstrumentLogLogic();

			// Create Connection
			store = logLogic.createGridStore();

			// Delete Row
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);

			String containerName = "weather_station_1";
			// Get TimeSeries Container
			TimeSeries<InstrumentLog> logTs =
					store.getTimeSeries(containerName, InstrumentLog.class);
			Date deleteTime = format.parse("2016/07/02 12:00");

			System.out.println(containerName + " ################");
			System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture");

			// Delete the Instrument log of the specified time
			boolean deleteSuccessed = logTs.remove(deleteTime);
			System.out.println("Delete Result:" + deleteSuccessed);

			InstrumentLog log = logTs.get(format.parse("2016/07/02 12:00"));
			if (log == null) {
				System.out.println("Deleted log at 2016/07/02 12:00");
			}

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
