package sample;

import java.io.IOException;
import java.util.List;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;

import sample.logic.WeatherStationLogic;
import sample.row.WeatherStation;

/**
 * Sample of data registration of Collection.
 */
public class CollectionRegister {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			WeatherStationLogic wsLogic = new WeatherStationLogic();

			// Create Connection
			store = wsLogic.createGridStore();

			// Read WeatherStation data from csv
			List<WeatherStation> weatherStationList = wsLogic.readCsv();
			// Register Collection
			wsLogic.registerCollection(store, weatherStationList);

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} catch (IOException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw other than,
			// because the change of the previous commit is not canceled,
			// if necessary, to call abort()

			// In auto-commit mode on, if the GSException throw other than,
			// because the change of the previous commit is canceled,
			// it is not necessary to call abort()
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
