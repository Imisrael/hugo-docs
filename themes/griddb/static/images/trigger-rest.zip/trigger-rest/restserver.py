import sys
import json
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer

class JsonResponseHandler(BaseHTTPRequestHandler):

	def do_POST(self):
		content_len = int(self.headers.get('content-length'))
		body = self.rfile.read(content_len).decode('UTF-8')
		jsonBody = json.loads(body)
		print(json.dumps(jsonBody, indent=4))
		self.send_response(200)
		self.send_header('Content-type', 'text/json')
		self.end_headers()

server = HTTPServer(('', 80), JsonResponseHandler)
server.serve_forever()