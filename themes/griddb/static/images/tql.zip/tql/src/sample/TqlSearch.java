package sample;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Query;
import com.toshiba.mwcloud.gs.RowSet;
import com.toshiba.mwcloud.gs.TimeSeries;
import com.toshiba.mwcloud.gs.TimestampUtils;

import sample.logic.GridDBLogic;
import sample.row.InstrumentLog;
import sample.row.WeatherStation;

/**
 * Sample of Seach TQL
 */
public class TqlSearch {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);

			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Search InstrumentLog by Temperture
			RowSet<InstrumentLog> rows = searchByTemperture(store, 70.0);
			System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture");
			while (rows.hasNext()) {
				InstrumentLog log = rows.next();
				System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp,
						log.weatherStationId, log.temperture));
			}

			// Search WeatherStation by name
			RowSet<WeatherStation> wsRows = searchByName(store, "kyo");

			// Show search WeatherStation results
			System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
			while (wsRows.hasNext()) {
				WeatherStation weatherStation = wsRows.next();
				System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s",
						weatherStation.id, weatherStation.name, weatherStation.latitude,
						weatherStation.longitude, weatherStation.hasCamera));

				// Search InstrumentLog by Timestamp
				Date start = format.parse("2016/07/02 6:00:00");
				Date end = format.parse("2016/07/02 12:00:00");
				RowSet<InstrumentLog> logRows =
						searchByTimestamp(store, weatherStation.id, start, end);
				// Show search InstrumentLog results
				System.out.println("Timestamp\t\t\tWeatherStation ID\tTemperture");
				while (logRows.hasNext()) {
					InstrumentLog log = logRows.next();
					System.out.println(String.format("%s\t%-20s\t%-10s", log.timestamp,
							log.weatherStationId, log.temperture));
				}
			}


		} catch (GSException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

	/**
	 * Search InstrumentLog by the Temperture.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param temperture Temperture of InstrumentLog
	 * @return Search Results Row of InstrumentLog.
	 * @throws GSException
	 */
	private static RowSet<InstrumentLog> searchByTemperture(GridStore store, double temperture)
			throws GSException {
		// Get TimeSeries Container
		TimeSeries<InstrumentLog> logTs =
				store.getTimeSeries("weather_station_1", InstrumentLog.class);

		// Seach by temperture
		String tql = String.format("SELECT * WHERE temperture > %s", temperture);
		System.out.println("TQL:" + tql);
		Query<InstrumentLog> query = logTs.query(tql, InstrumentLog.class);
		RowSet<InstrumentLog> rows = query.fetch();
		return rows;
	}

	/**
	 * Like Search by the Name of WeatherStation.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param name Name of WeatherStation
	 * @return Search Results Row of WeatherStation.
	 * @throws GSException
	 */
	private static RowSet<WeatherStation> searchByName(GridStore store, String name)
			throws GSException {
		// Get Collection
		Collection<String, WeatherStation> weatherStationCol =
				store.getCollection("weather_station", WeatherStation.class);

		// Like Seach
		String tql = "SELECT * WHERE name LIKE '%" + name + "%'";
		System.out.println("TQL:" + tql);
		// Search By TQL
		Query<WeatherStation> query = weatherStationCol.query(tql, WeatherStation.class);
		RowSet<WeatherStation> rows = query.fetch();
		return rows;
	}

	/**
	 * Search InstrumentLog by the Timestamp range.
	 *
	 * @param store Instance of GridStore that are not close.
	 * @param weatherStationId ID of WeatherStation
	 * @param start Search start time
	 * @param end Search end time
	 * @return Search Results Row of InstrumentLog.
	 * @throws GSException
	 */
	private static RowSet<InstrumentLog> searchByTimestamp(GridStore store, String weatherStationId,
			Date start, Date end) throws GSException {
		// Get TimeSeries Container
		TimeSeries<InstrumentLog> logTs =
				store.getTimeSeries("weather_station_" + weatherStationId, InstrumentLog.class);

		String tql = String.format(
				"SELECT * WHERE TIMESTAMP('%s') <= timestamp AND timestamp <= TIMESTAMP('%s')",
				TimestampUtils.format(start), TimestampUtils.format(end));
		System.out.println("TQL:" + tql);
		Query<InstrumentLog> query = logTs.query(tql);
		RowSet<InstrumentLog> rows = query.fetch();
		return rows;
	}

}
