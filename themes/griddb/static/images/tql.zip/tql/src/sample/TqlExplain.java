package sample;

import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Query;
import com.toshiba.mwcloud.gs.QueryAnalysisEntry;
import com.toshiba.mwcloud.gs.RowSet;
import com.toshiba.mwcloud.gs.TimeSeries;

import sample.logic.GridDBLogic;
import sample.row.InstrumentLog;

/**
 * Sample of Explain TQL
 */
public class TqlExplain {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Get InstrumentLog TimeSeries
			TimeSeries<InstrumentLog> logTs =
					store.getTimeSeries("weather_station_1", InstrumentLog.class);

			// Analyzing the execution plan of the TQL
			String tql = "EXPLAIN ANALYZE SELECT * WHERE 50.0 <= temperture AND temperture <= 70.0"
					+ " AND TIMESTAMP('2016-07-01T06:00:00Z') <= timestamp";
			Query<QueryAnalysisEntry> query = logTs.query(tql, QueryAnalysisEntry.class);
			RowSet<QueryAnalysisEntry> rows = query.fetch();

			// output the execution plan of the TQL
			System.out.println("ID\tDepth\tType\t\t\t\tValueType\tValue\t\t\tStatement");
			while (rows.hasNext()) {
				QueryAnalysisEntry analysis = rows.next();
				System.out.println(String.format("%s\t%s\t%-24s\t%-10s\t%-20s\t%s",
						analysis.getId(), analysis.getDepth(), analysis.getType(),
						analysis.getValueType(), analysis.getValue(), analysis.getStatement()));
			}

		} catch (GSException e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}
}
