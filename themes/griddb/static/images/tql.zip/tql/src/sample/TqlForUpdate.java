package sample;

import com.toshiba.mwcloud.gs.Collection;
import com.toshiba.mwcloud.gs.GSException;
import com.toshiba.mwcloud.gs.GridStore;
import com.toshiba.mwcloud.gs.Query;
import com.toshiba.mwcloud.gs.RowSet;

import sample.logic.GridDBLogic;
import sample.row.WeatherStation;

/**
 * Sample of TQL using forUpdate
 */
public class TqlForUpdate {

	public static void main(String[] args) throws GSException {
		GridStore store = null;
		try {
			GridDBLogic gridLogic = new GridDBLogic();

			// Create Connection
			store = gridLogic.createGridStore();

			// Get TimeSeries
			Collection<String, WeatherStation> weatherStationCol =
					store.getCollection("weather_station", WeatherStation.class);

			// When using forUpdate, there is a need to disable the Auto Commit
			weatherStationCol.setAutoCommit(false);

			// In the case of boolean columns, NOT means false.
			String tql = "SELECT * WHERE NOT hasCamera";
			// Search By TQL
			Query<WeatherStation> query = weatherStationCol.query(tql, WeatherStation.class);
			// Using forUpdate option.
			RowSet<WeatherStation> rows = query.fetch(true);

			// Install a camera in all of WeatherStation.
			while (rows.hasNext()) {
				System.out.println("not exists camera");
				WeatherStation weatherStation = rows.next();
				System.out.println("ID:" + weatherStation.id);
				weatherStation.hasCamera = true;
				// update row of WeatherStation
				rows.update(weatherStation);
			}
			// Commit
			weatherStationCol.commit();

			// Retrieve WeatherStation Collection
			Collection<String, WeatherStation> weatherStationColResult =
					store.getCollection("weather_station", WeatherStation.class);

			System.out.println("ID\tName\t\t\tLongitude\tLatitude\tCamera");
			for (int i = 0; i < GridDBLogic.JP_PREFECTURE; i++) {
				// Retrieve row by key
				WeatherStation weatherStation = weatherStationColResult.get(String.valueOf(i + 1));
				System.out.println(String.format("%-3s\t%-20s\t%-10s\t%-10s\t%-5s",
						weatherStation.id, weatherStation.name, weatherStation.latitude,
						weatherStation.longitude, weatherStation.hasCamera));
			}

		} catch (GSException e) {
			e.printStackTrace();
			// In auto-commit mode off, if the GSException throw,
			// change before the commit is canceled

			// In auto-commit mode on, if the GSException throw,
			// change before the commit is canceled
		} finally {
			// Close Connection
			if (store != null) {
				store.close();
			}
		}
	}

}
